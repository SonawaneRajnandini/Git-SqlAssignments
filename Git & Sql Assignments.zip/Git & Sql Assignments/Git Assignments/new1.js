console.log()
alert()
document.write()